let data = document.querySelector(".data");
document.getElementById("addPerson").onclick = function(){
    data.classList.toggle("hideElement");
};
let createdRow = 0;

function cancelData(){
    data.classList.add("hideElement");
}
function save(event){
    createdRow++;

    event.preventDefault(); // I used this function to prevent the page from refreshing itself
    //getting data from form
    let cin = document.getElementById("cin").value;
    let firstName = document.getElementById("firstName").value;
    let lastName = document.getElementById("lastName").value;
    let city = document.getElementById("city").value;

    let table = document.getElementById("table");
    //creating tr element using js
    let tr = document.createElement("tr");
    tr.id = `tr${createdRow}`;
    tr.classList.add("item");

    //data
    let info = [cin,firstName,lastName,city];
    for (let i = 0;i < info.length - 1;i++){
        let td = document.createElement("td");
        td.textContent = info[i];
        tr.appendChild(td);
        table.appendChild(tr);
    }

    let actionsTd = document.createElement("td");
    let buttonsName = ["display","delete","edit"];
    let classNames = ["displayBtn","deleteBtn","editBtn"];
    /* let functions = [displayElement,deleteElement,editElement] */
    for (let i = 0;i < buttonsName.length;i++){
        let button = document.createElement("button");
        button.textContent = buttonsName[i];
        button.classList.add(classNames[i]);

        /* button.addEventListener("click",functions[i]); */
        if (button.textContent == "display"){
            button.onclick = function(){
                //getting display box by class name
                let displayData = document.querySelector(".displayData");
                displayData.classList.remove("hideElement");
                displayData.innerHTML = `<label>Personal Information</label><br>;
                <label>CIN: ${cin}</label><br>
                <label>FIRSTNAME: ${firstName} </label><br>
                <label>LASTNAME: ${lastName} </label><br>
                <label>CITY: ${city} </label><br>   
                <button onclick="closeDisplay()">Cancel</button>

                `;
            };
        }
        if (button.textContent == "delete"){
            button.onclick = function(){   
                //method 1 
                /* button.parentElement.parentElement.remove(); */

                //method 2
                let confBox = document.querySelector(".confBox");
                confBox.classList.remove("hideElement");
                //delete
                document.getElementById("yesBtn").onclick = function(){
                    tr.remove();
                confBox.classList.add("hideElement");
                };

                document.getElementById("noBtn").onclick = function(){
                    confBox.classList.add("hideElement");
                };
            };
        }
        if (button.textContent == "edit"){
            button.onclick = function(){
                let modBox = document.querySelector(".modBox");
                modBox.classList.remove("hideElement");
                modBox.querySelector("#newcin").value = cin;
                modBox.querySelector("#newfirstName").value = firstName;
                modBox.querySelector("#newlastName").value = lastName;
                modBox.querySelector("#newcity").value = city;
                modBox.innerHTML += `<button onclick="update(tr${createdRow})">Update</button>`;
            };
        }

        actionsTd.appendChild(button);
    }
    tr.appendChild(actionsTd);
    
    data.classList.add("hideElement");
}

function closeDisplay(){
    document.querySelector(".displayData").classList.add("hideElement");
    
}
function update(tr){
    tr.children[0].textContent = document.getElementById("newcin").value;
    tr.children[1].textContent = document.getElementById("newfirstName").value;
    tr.children[2].textContent = document.getElementById("newlastName").value;
}

document.getElementById("search").addEventListener("input",() =>{
    let rows = document.querySelectorAll(".item");

    let searchValue = document.getElementById("search").value.trim();
    rows.forEach((row) =>{
        
        if (searchValue.length !== 0){
            if (row.textContent.includes(searchValue)){
            row.style.display = "";
        }
            else{
                row.style.display = "none";
            }
    }
    if (searchValue.length === 0){
        row.style.display = "";
    }
    });

});